# Fleet Sales — Phase 2 UAT Package

This restores the **exact** database I built and tested: Odoo 19,
`fleet_sales_core` installed, demo data loaded, all 6 UAT logins already
created with the passwords below. Two commands and you're testing in a
real browser on your own machine.

## Requirements

Docker and Docker Compose. Nothing else — Odoo and PostgreSQL both run in
containers.

## 1. Start the database container only

```bash
docker compose up -d db
```

Wait about 10 seconds for PostgreSQL to finish initializing, then restore
the dump into it:

```bash
docker compose exec -T db createdb -U odoo fleet_sales_dev
cat fleet_sales_dev.dump | docker compose exec -T db pg_restore -U odoo -d fleet_sales_dev --no-owner --no-privileges
```

(You'll see a handful of harmless `NOTICE`/`WARNING` lines about
ownership — expected, since we restore with `--no-owner`.)

## 2. Start Odoo

```bash
docker compose up -d odoo
```

Give it ~15–20 seconds on first boot, then open:

**http://localhost:8069/odoo?db=fleet_sales_dev**

## 3. Log in

| Role | Login | Password |
|---|---|---|
| General Manager | `gm@fleetsales.demo` | `Uat!GM-2026` |
| Regional Manager (Central) | `rm.central@fleetsales.demo` | `Uat!RM-2026` |
| Supervisor (Central) | `supervisor.central@fleetsales.demo` | `Uat!Sup-2026` |
| Salesman (Central) | `salesman1@fleetsales.demo` | `Uat!Sales1-2026` |
| Salesman #2 (Central) | `salesman2@fleetsales.demo` | `Uat!Sales2-2026` |
| Finance | `finance@fleetsales.demo` | `Uat!Fin-2026` |
| Supervisor (Western) | `supervisor.western@fleetsales.demo` | `Uat!SupW-2026` |
| Salesman (Western) | `salesman.western@fleetsales.demo` | `Uat!SalesW-2026` |

The last two exist specifically so you can confirm the Central Regional
Manager (`rm.central@…`) **cannot** see Western's team or requests — that
isolation can't be tested with only one region populated.

## What's already in the database

- **Regions:** Central, Western, Eastern (Eastern is empty — deliberately,
  to check nothing leaks into an unrelated empty region either)
- **Sectors:** Grocery, HORECA, Pharmacy, Convenience Store, Bakery
- **New Customer Requests:**
  - *Al Rawabi Grocery* — already **approved** (submitted by Salesman 1,
    approved by the system) → click through to see the Customer it created
  - *Al Waha Mini Market* — **submitted**, awaiting Supervisor decision
    (submitted by Salesman 2)
  - *Jeddah Fresh Mart* — **submitted**, in the **Western** region
    (submitted by the Western salesman) — this is the cross-region record
- **New POS Location Request:** *Al Fanar – Olaya Branch*, **submitted**,
  against an existing customer (*Al Fanar Trading Co.*), awaiting approval

## Stopping / restarting

```bash
docker compose down        # stop everything, keep the data
docker compose down -v     # stop and wipe the data (start over from the dump)
docker compose up -d       # bring it back up later
```

## If something looks wrong

This is the same code and the same database I ran 11/11 automated tests
against and manually walked through in a browser before packaging it —
if you hit an error here, it's either environment-specific (Docker/Postgres
version mismatch) or a real bug I should know about. Either way, tell me
exactly what you clicked and what happened.
