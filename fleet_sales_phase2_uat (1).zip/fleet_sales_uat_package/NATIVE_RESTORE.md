# Restoring into your existing local Odoo 19 install

This is the primary path — restore straight into the PostgreSQL and Odoo
19 you already have running, no Docker, no VPS. I actually ran every
command below against a fresh test database before writing it down, so
this isn't a guess.

## 0. What's in this package

```
fleet_sales_dev.dump      PostgreSQL custom-format dump (pg_dump -Fc)
addons/fleet_sales_core/  the custom module — all of Phase 2, nothing else
docker-compose.yml        optional — ignore this if you're going native
README.md                 the Docker version of these instructions
```

## 1. Dependencies

None beyond a working Odoo 19 install. `fleet_sales_core` only depends on
`base`, `mail`, and `base_setup` — all three ship with every Odoo 19
install, so there's nothing extra to `pip install` or `apt install`.

## 2. Put the module where your local Odoo can see it

Copy the whole folder into wherever your local instance's custom addons
live, e.g.:

```bash
cp -r addons/fleet_sales_core /path/to/your/custom-addons/
```

Then make sure that directory is on your `addons_path`. In your
`odoo.conf`:

```ini
[options]
addons_path = /path/to/odoo/addons,/path/to/your/custom-addons
```

(Comma-separated, no spaces around the comma matters in some Odoo
versions — keep it exactly like that.) If you normally pass
`--addons-path` on the command line instead of a config file, just add
the custom-addons folder to that same comma-separated list.

## 3. Restore the database

The dump is **custom format** (`pg_dump -Fc`), so it needs `pg_restore`,
not `psql -f`.

```bash
createdb -U <your_pg_user> fleet_sales_dev
pg_restore -U <your_pg_user> -d fleet_sales_dev --no-owner --no-privileges fleet_sales_dev.dump
```

Replace `<your_pg_user>` with whatever role your local Odoo already
connects as (often your own OS username with peer auth, or `odoo`/
`postgres` with password auth — whatever you already use to create other
Odoo databases locally works here too).

**One real gotcha I hit while testing this:** if `createdb`/`pg_restore`
fail with `Peer authentication failed`, it means you're invoking them
without `-h`, so Postgres is trying to match your *OS* username to a DB
role of the same name over the local socket. Add `-h 127.0.0.1` (forces
password auth over TCP instead) or run the commands as the matching OS
user. Either fixes it — I hit exactly this and that's the fix.

You'll see a handful of harmless `NOTICE`/`WARNING` lines about ownership
during restore — expected with `--no-owner --no-privileges`, not an
error.

## 4. Run one update pass

Even though the dump already has the module marked "installed," run this
once so Odoo recompiles views/assets against *your* local Odoo 19
checkout rather than assuming it's byte-identical to mine:

```bash
odoo-bin -d fleet_sales_dev -u fleet_sales_core --addons-path=/path/to/odoo/addons,/path/to/your/custom-addons --stop-after-init
```

(Or `-i fleet_sales_core` instead of `-u` only if the update reports the
module as not found/not installed — it shouldn't, since the dump already
has it installed, but `-i` is idempotent if you need it.)

## 5. Start Odoo and log in

```bash
odoo-bin -d fleet_sales_dev --addons-path=/path/to/odoo/addons,/path/to/your/custom-addons
```

Open **http://localhost:8069/odoo?db=fleet_sales_dev** (the explicit
`?db=` skips the database-selector screen if you have other local
databases too).

## 6. Test logins

| Role | Login | Password |
|---|---|---|
| General Manager | `gm@fleetsales.demo` | `Uat!GM-2026` |
| Regional Manager (Central) | `rm.central@fleetsales.demo` | `Uat!RM-2026` |
| Supervisor (Central) | `supervisor.central@fleetsales.demo` | `Uat!Sup-2026` |
| Salesman (Central) | `salesman1@fleetsales.demo` | `Uat!Sales1-2026` |
| Salesman #2 (Central) | `salesman2@fleetsales.demo` | `Uat!Sales2-2026` |
| Finance | `finance@fleetsales.demo` | `Uat!Fin-2026` |
| Supervisor (Western) | `supervisor.western@fleetsales.demo` | `Uat!SupW-2026` |
| Salesman (Western) | `salesman.western@fleetsales.demo` | `Uat!SalesW-2026` |

## 7. What's already loaded (configuration & workflow state, not just rows)

- **Regions:** Central, Western, Eastern (Eastern empty on purpose)
- **Sectors:** Grocery, HORECA, Pharmacy, Convenience Store, Bakery
- **Security groups:** all 5 Field Sales groups installed with the
  implied-group chain live (check any user's *Field Sales* tab under
  Settings → Users to see it)
- **Requests, mid-workflow, not just draft rows:**
  - *Al Rawabi Grocery* — customer request already **Approved**, with
    the Customer record it created linked via the stat button
  - *Al Waha Mini Market* — **Submitted**, awaiting a Supervisor decision
  - *Jeddah Fresh Mart* — **Submitted**, in the **Western** region (the
    record the Central Regional Manager must not be able to see)
  - *Al Fanar – Olaya Branch* — a **Submitted** POS Location request
    against an existing customer, awaiting approval

## 8. Filestore note (for completeness, not because it matters here)

Odoo stores large binary attachments on disk (the "filestore"), separate
from the SQL dump. Nothing in this demo data uses file attachments or
uploaded images, so there's no filestore directory to copy — the dump is
self-contained for everything you'll actually test.

## Coffee Kiosk

Untouched. Nothing in this package or in producing it touched
`Local-git-demo` or the `coffee_kiosk_pos`/`coffee_recipe_costing`
modules.
